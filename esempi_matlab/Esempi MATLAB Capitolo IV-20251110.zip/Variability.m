close all
clear all

%import excel
% measurements of liver T2* values with two methods 

T = readtable('ROI_vs_PW.xls');

Td  =table2array(T);



%COV
dA = abs(Td(:,1)-Td(:,2));
m = mean(Td,2);
CV = std(100*dA./m)

%regression line
x = Td(:,2);
y = Td(:,1);

figure
scatter(x,y)
hold on
plot(1:40,1:40)

% regression line
p = polyfit(x,y,1)
yfit =  p(1) * x + p(2);
plot(x,yfit)


BlandAltman(x, y)

% paired t-test
p=ttest(x,y,Alpha=0.05)


% diagnostc efficacy
th = 18; % lower limit of normal for T2* value for iron overload

% x gold standard -> correct diagnosis
ironOverloadGS = logical(x < th);
ironOverloadEst = logical(y < th);

sum(ironOverloadGS) % patients with iron overload

VP = sum(ironOverloadGS  & ironOverloadEst) 
VN = sum(not(ironOverloadGS)  & not(ironOverloadEst)) 
FP = sum(not(ironOverloadGS)  & (ironOverloadEst)) 
FN = sum((ironOverloadGS)  & not(ironOverloadEst)) 

Sensitivity = VP./(VP+FN)
Specificity = VN./(VN+FP)
Accuracy = (VN+VP)./(VN+VP+FP+FN)

% ROC curve
[X,Y,T,AUC] = perfcurve(string(ironOverloadEst),x,'false')

figure
plot(X,Y)
xlabel('False positive rate') 
ylabel('True positive rate')
title('ROC for Classification by Logistic Regression')


