% esempio bfscore
close all
clear all

image=dicomread('phantom.dcm'); % load phantom image
image=double(image);


% open image segmenter save contours as AC and Manual
imageSegmenter(image);

figure
subplot(1,2,1)
imagesc(Manual)
colormap gray
title('Manual');
subplot(1,2,2)
imagesc(AC)
colormap gray
title('Active Contours');

dice(AC,Manual)
jaccard(AC,Manual)
bfscore(AC,Manual)
