% esempio DICE/JACCARD
close all
clear all

image=dicomread('phantom.dcm'); % load phantom image
image=double(image);
sz=size(image);

% obtain water mask by kmeans clustering
[idx C]=kmeans(image(:),3);  % apply kmeans, we choice 3 clusters from the histogram shape
[C id]=sort(C) % order centroids 
id = find(idx == id(2)); % water mask
maskW=zeros(sz);
maskW(id)=255;
[L sizeL]= bwlabel(maskW); % labeling 
stats = regionprops(L); % measure blobs areas
areas=cat(1,stats.Area); % find larger object
[maxSize id] = max(areas);
maskWKM=zeros(sz);   % water mask by kmeans
idx = find(L ==id);
maskWKM(idx)=255; 
maskWKM=logical(maskWKM);

% obtain water mask by region growing
xP=107; % pixel in water
yP=49; 
T=50;
maskWRG=grayconnected(image,yP,xP,T);

%compute dice and jaccard indices
diceIndex=dice(logical(maskWKM),logical(maskWRG));
jaccardIndex=jaccard(logical(maskWKM),logical(maskWRG));

figure('NumberTitle', 'off', 'Name', ['DICE = ' num2str(diceIndex) '  ' 'JACCARD = ' num2str(jaccardIndex)]);
axis('image') % preserve image proportions
subplot(2,2,1)
imagesc(maskWKM) 
title('Kmeans segmetation');
subplot(2,2,2)
colormap gray
imagesc(maskWRG)
title('RG segmetation');
colormap(gca,'gray')
subplot(2,2,3)
imagesc(maskWKM & maskWRG)
title('TP (Overlapping Area)');
subplot(2,2,4)
imagesc(maskWKM | maskWRG)
title('Areas Union');


figure('NumberTitle', 'off', 'Name', 'Algoritmo Region Growing / threshold');
axis('image') % preserve image proportions
for T=1:1:500
    maskWRG=grayconnected(image,yP,xP,T);
    axis('image') % preserve image proportions
    subplot(2,2,1)
    imagesc(maskWKM) 
    title('Kmeans segmetation');
    subplot(2,2,2)
    colormap gray
    imagesc(maskWRG)
    title('RG segmetation');
    colormap(gca,'gray')
    subplot(2,2,3)
    imagesc(maskWKM & maskWRG)
    title('TP (Overlapping Area)');
    subplot(2,2,4)
    imagesc(maskWKM | maskWRG)
    title('Areas Union');
    drawnow
end

figure('NumberTitle', 'off', 'Name', 'Algoritmo Region Growing / threshold');
axis('image') % preserve image proportions
D=zeros(1,500);
J=zeros(1,500);
for T=1:1:500
    maskWRG=grayconnected(image,yP,xP,T);
    D(T)=dice(logical(maskWKM),logical(maskWRG));
    J(T)=jaccard(logical(maskWKM),logical(maskWRG));
    plot(1:500,D)
    hold on
    plot(1:500,J)
    ylim([0 1]);
    hold off
    legend('DICE', 'JACCARD')
    drawnow
end
