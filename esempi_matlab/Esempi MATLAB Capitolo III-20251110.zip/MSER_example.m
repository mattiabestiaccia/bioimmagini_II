%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Vincenzo Positano (vincenzo.positano@ing.unipi.it)
%%% materiale di supporto al corso di Bioimmagini 2019
%%% esempio MSER semplificato (cap 3)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear all

figure('NumberTitle', 'off', 'Name', 'Esempio semplificato MSER');
axis image
colormap gray
I = dicomread('phantom.dcm'); %load phantom image
imagesc(I)

%MSER simplified algorithm
pixelList=sort(I(:)); % sort pixel list
tmp=zeros(size(I)) ; % "empty" image

G = unique(pixelList); % cut-off of repated gray values

%prepare figure
figure('NumberTitle', 'off', 'Name', 'Evoluzione MSER');
axis image

nLabels=zeros(1,length(G));
for g=1:length(G)  % cycle on gray values
    id  = find (I == G(g)); % gray values equal to the current gray level in image
    tmp(id)= 1; % update tmp
    [L, n] = bwlabeln(tmp,4); % labeling
    Labels(g,:,:)=L; % update labels list
    nLabels(g)=n;   % update number of labels
    subplot(1,2,1)
    imagesc(L)
    subplot(1,2,2)
    plot(1:length(G),log(nLabels))
    drawnow
    pause(0.01)
end


% we follow the background area (the bigger one)
figure('NumberTitle', 'off', 'Name', 'Segmentazione Sfondo');
axis image
map=zeros([length(G),size(I)]);
for g=1:length(G)  % cycle on labels
    currentLab=squeeze(Labels(g,:,:)); % labeling data
    for n=1:nLabels(g)              % find the bigger object
        id=find(currentLab == n);
        area(n)=length(id);
    end
    [A idmax]=max(area); % find the larger object
    id=find(currentLab == idmax); % background
    areaBK(g)=length(id); % background area        
    map(g,id)=255;
    imagesc(squeeze(map(g,:,:)))
    drawnow
end

figure('NumberTitle', 'off', 'Name', 'Variazione Area Sfondo');
plot(areaBK) % areas 
hold on
var=50*diff(areaBK); % areas varaition (rescaled)
plot(var)
id0=find(diff(areaBK) == 0); % maximum stable regions (no variations)
% show maximum stable region
figure('NumberTitle', 'off', 'Name', 'Aree Stabili');
axis image
for i=1:length(id0)
    imagesc(squeeze(map(id0(i),:,:)))
    drawnow
end


% MSER 
I=double(I);
Inorm=round(I*255.0/max(I(:)));
Inorm=uint8(Inorm);  % 8-bit binary mask needed !!!!!!!!!!!!
 
regions = detectMSERFeatures(Inorm,'ThresholdDelta',2.8,'MaxAreaVariation',3,'RegionAreaRange',[3000 50000]);
%regions = detectMSERFeatures(Inorm,'RegionAreaRange',[3000 10000]);
plot(regions,'showPixelList',true,'showEllipses',false);

