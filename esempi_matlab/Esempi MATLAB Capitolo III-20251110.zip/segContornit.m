% esemmpio base di segmentazione a contorni
close all
clear all

image = dicomread('phantom.dcm'); %  load MR phantom
info = dicominfo('phantom.dcm');

% display phantom
figure('NumberTitle', 'off', 'Name', 'Immagine Phantom e profilo');
axis('image') % preserve image proportions
colormap gray
subplot(1,2,1)
tmp=image
tmp(127,:)=1000;
imagesc(tmp)

%display profile and profile derivate
profile=image(127,:);
deriv=diff(profile)
subplot(1,2,2)
plot(profile)
hold on
plot(deriv)

% find tissue transictions 
tmp=image;
T=100 ; % derivate threshold
id=find(abs(deriv) > T);
cont=zeros(length(profile));
x=1:length(profile);
cont(:)=255;
cont=cont(id)
x=x(id);
tmp(127,id)=2000;
figure('NumberTitle', 'off', 'Name', 'Transizioni');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(tmp)
subplot(1,2,2)
plot(profile)
hold on
plot(abs(deriv))
hold on
plot(x,cont,'*')


% working in 2D space by edge function
figure('NumberTitle', 'off', 'Name', 'edge map');
axis('image') % preserve image proportions
colormap gray
edgeMap=edge(image);
imagesc(edgeMap)

%create contours from edge map
% apply labeling to separate contours
blobs=bwlabel(edgeMap,8); % note 8-pixel connection 
figure('NumberTitle', 'off', 'Name', 'edge map');
axis('image') % preserve image proportions
imagesc(blobs)

% in blobs we have single contours masks
nblobs=max(blobs(:)) %number of contours should be 5 but it is difficult to separe internal water contours

id=find(blobs == 1); % select first contour
mask=zeros(size(image));
mask(id)=1;
figure('NumberTitle', 'off', 'Name', 'first contour mask');
axis('image') % preserve image proportions
imagesc(mask)

% extract contour as a coordinates list
figure('NumberTitle', 'off', 'Name', 'contour reconstruction');
axis('image') % preserve image proportions
cmask=zeros(size(image));
xC=zeros(1,length(id)); % coordinates, id number of points
yC=zeros(1,length(id));
[x y]=ind2sub(size(mask),id(1)); % first point coordinates, use ind2sub to convert index to coordinates 
xC(1)=x; % store coordinates
yC(1)=y;
mask(xC(1),yC(1))=0;                      % cancel the first point from the list
cmask(xC(1),yC(1))=1;                     % store the first point from the list
for i=2:length(id)
    searchSpace=mask(xC(i-1)-1:xC(i-1)+1,yC(i-1)-1:yC(i-1)+1); %search kernel (3x3)
    mId=find(searchSpace == 1); %find contour pixel in the kernel
    [x y]=ind2sub(size(searchSpace),mId(1)); % i-th point in kernel coordinates
    xC(i)=xC(i-1)+x-2;                       % i-th point in image coordinates      
    yC(i)=yC(i-1)+y-2;
    mask(xC(i),yC(i))=0;                     % cancel the i-th point from the list
    cmask(xC(i),yC(i))=1;                    % store the i-th point from the list
    imagesc(cmask)
    drawnow
end

%------------------------------------------------------------
%---- wrong identification -------------

% id=find(blobs == 3); % 3-th contour
% mask=zeros(size(image));
% mask(id)=1; 
% figure('NumberTitle', 'off', 'Name', 'first contour mask');
% axis('image') % preserve image proportions
% imagesc(mask)
% figure('NumberTitle', 'off', 'Name', 'contour reconstruction');
% axis('image') % preserve image proportions
% cmask=zeros(size(image));
% xC=zeros(1,length(id));
% yC=zeros(1,length(id));
% [x y]=ind2sub(size(mask),id(1)); % first point)
% xC(1)=x;
% yC(1)=y;
% mask(xC(1),yC(1))=0;                     % cancel the first point from the list
% cmask(xC(1),yC(1))=1;                     % cancel the first point from the list
% for i=2:length(id)
%     searchSpace=mask(xC(i-1)-1:xC(i-1)+1,yC(i-1)-1:yC(i-1)+1); %search kernel
%     mId=find(searchSpace == 1); %find contour pixel in the kernel
%     [x y]=ind2sub(size(searchSpace),mId(1)); % i-th point
%     xC(i)=xC(i-1)+x-2;
%     yC(i)=yC(i-1)+y-2;
%     mask(xC(i),yC(i))=0;                     % cancel the i-th point from the list
%     cmask(xC(i),yC(i))=1;
%     imagesc(cmask)
%     drawnow
% end


%edgeMap=edge(image,'canny');
%[edgeMap th]=edge(image,'canny',0.05);

