%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Vincenzo Positano (vincenzo.positano@ing.unipi.it)
%%% materiale di supporto al corso di Bioimmagini 2019
%%% esempio watershed/MSER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear all

% display phantom
figure('NumberTitle', 'off', 'Name', 'Dimostrazione watershed/MSER');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
I = dicomread('phantom.dcm'); % load MR phantom
s=size(I);
dim=s(1);
imagesc(I)
subplot(1,2,2)
plot(I(:,dim/2)) %plot profile


% create watershed plot
figure('NumberTitle', 'off', 'Name', 'watershed');
colormap gray
maxImage=max(I(:)); %image deep
%area=zeros(1,maxImage);
for th=1:maxImage % cycle on possible thresholds
    BW = grayconnected(I,4,4,th); % calculate water surface mask
    s1=subplot(1,3,1);
    BWc=zeros(dim,dim,3); %color image
    BWc(:,:,1)=BW;
    imshowpair(I,BWc,'blend');
    axis image
    area(th)=sum(BW(:)); % calculate water surfare area
    s2=subplot(1,3,2);
    
    plot(1:th,area,'r','LineWidth',2.0)
    ylim([0 length(I(:))]);
    xlim([0 maxImage]);
    s2.PlotBoxAspectRatio=s1.PlotBoxAspectRatio;
    s3=subplot(1,3,3);
    plot(I(:,dim/2),'k') %plot profile
    hold on
    %lh=yline(th,'r');
    lh=plot(1:dim,double(th).*ones(1,dim),'r');
    lh.Color(4) = 0.2;
    s3.PlotBoxAspectRatio=s1.PlotBoxAspectRatio;
    
    pause(0.1)
    drawnow
end
g=gradient(area); % gradient of surface area

% plot
figure('NumberTitle', 'off', 'Name', 'Superfice vs soglia');
plot(area/max(area(:)))
hold on
plot(g/max(g(:)))

% define threshoolds between gradient peaks
% automated version welcome :-) Please, send me 
BW1 = grayconnected(I,4,4,200); % extract masks
BW2 = grayconnected(I,4,4,500);
BW3 = grayconnected(I,4,4,650);
BW4 = grayconnected(I,4,4,950);
 
figure('NumberTitle', 'off', 'Name', 'Segmentazione');
axis image
colormap gray
subplot(1,4,1)
imagesc(BW1)
title('Thr = 200')
subplot(1,4,2)
imagesc(BW2)
title('Thr = 500')
subplot(1,4,3)
imagesc(BW3)
title('Thr = 650')
subplot(1,4,4)
imagesc(BW4)
title('Thr = 950')
 
% subtracting masks we have objects
% note that topological separation is done by a threshold segmentation 
figure('NumberTitle', 'off', 'Name', 'Segmentazione Differenza');
axis image
colormap gray
subplot(1,4,1)
imagesc(BW1)
subplot(1,4,2)
imagesc(BW2-BW1)
subplot(1,4,3)
imagesc(BW3-BW2)
subplot(1,4,4)
imagesc(BW4-BW3)

 
 
