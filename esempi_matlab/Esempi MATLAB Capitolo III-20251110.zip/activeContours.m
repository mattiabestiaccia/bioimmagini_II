% esemmpio base di segmentazione a contorni attivi
close all
clear all

image = dicomread('phantom.dcm'); %  load MR phantom
info = dicominfo('phantom.dcm');

% display phantom
figure('NumberTitle', 'off', 'Name', 'Dimostrazione activecontours');
axis('image') % preserve image proportions
colormap gray
imagesc(image)
hold on
% select initial contour
initMask = roipoly; 
visboundaries(initMask,'Color','r'); % visualize initial contour visboundaries use bwboundaries to extract contours from a mask

endMask = activecontour(image, initMask, 100, 'Chan-Vese','ContractionBias',0.0); % active contour segmentation
visboundaries(endMask,'Color','g'); % visualize final contour 
drawnow

endMask = activecontour(image, initMask, 1000, 'edge','SmoothFactor',2.5,'ContractionBias',0.7); % active contour segmentation
visboundaries(endMask,'Color','b'); % visualize final contour 
