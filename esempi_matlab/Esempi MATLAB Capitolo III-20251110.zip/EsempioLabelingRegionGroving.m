% esempio labeling e Region Growing
close all
clear all

image=dicomread('phantom.dcm'); % load phantom image
image=double(image);
sz=size(image);

% display phantom image and image histogram 
figure('NumberTitle', 'off', 'Name', 'Fantoccio MR');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(image)
subplot(1,2,2)
[h edges]=histcounts(image(:));
x = edges(1:end-1)+ diff(edges)/2;
plot(x,h)

% obtain water mask by kmeans clustering
figure('NumberTitle', 'off', 'Name', 'Labeling');
axis('image') % preserve image proportions
subplot(1,3,1)
[idx C]=kmeans(image(:),3);  % apply kmeans, we choice 3 clusters from the histogram shape
imagesc(reshape(idx,sz(1),sz(2))) % display cluster maps, in color
[C id]=sort(C) % order centroids 
id = find(idx == id(2)); % water mask
mask=zeros(sz);
mask(id)=255;
subplot(1,3,2)
colormap gray
imagesc(mask)
colormap(gca,'gray')
L = bwlabel(mask); % labeling
subplot(1,3,3)
imagesc(L)
colormap(gca,'jet')
caxis([0 10]);

%region growing
xP=107; % pixel in water
yP=49; 
tmp=image;
tmp(yP,xP)=2000;
figure('NumberTitle', 'off', 'Name', 'Algoritmo Region Growing');
axis('image') % preserve image proportions
subplot(1,4,1)
imagesc(tmp)
title(['MR image '])
colormap(gca,'gray')
T=50;
mask=grayconnected(image,yP,xP,T);
subplot(1,4,2)
imagesc(mask)
title(['Threshold = ', num2str(T)])
T=100;
mask=grayconnected(image,yP,xP,T);
subplot(1,4,3)
imagesc(mask)
title(['Threshold = ', num2str(T)])
T=400;
mask=grayconnected(image,yP,xP,T);
subplot(1,4,4)
imagesc(mask)
title(['Threshold = ', num2str(T)])


figure('NumberTitle', 'off', 'Name', 'Algoritmo Region Growing / threshold');
axis('image') % preserve image proportions
nP=zeros(1,500)
for T=1:1:500
    subplot(1,2,1)
    mask=grayconnected(image,yP,xP,T);
    imagesc(mask)
    subplot(1,2,2)
    nP(T)=sum(mask(:));
    plot(1:500,nP)
    ylim([0 256*256]);
    drawnow
end


