%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Vincenzo Positano (vincenzo.positano@ing.unipi.it)
%%% materiale di supporto al corso di Bioimmagini 2019
%%% esempio skeletonization(cap 3)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


close all
clear all

% read mask (0-255), a very nice hippo
Ior = imread('hippo.jpg');
Ior = 1-double(Ior/255) ;

% kernels for thinning (-1 background, 1 foreground, 0 not defined)
k2 = [ -1  -1  -1
        0   1   0
        1   1   1]; 
   
k3 = [ 0   -1  -1
       1   1   -1
       0   1   0];
   
N=1 ; % number of iterations
I=Ior;  % start from original image
figure('NumberTitle', 'off', 'Name', 'Esempio thinning');
axis image
colormap gray
subplot(1,3,1)
imagesc(Ior)
title("Original Image")

for k = 1:N
    I = I - bwhitmiss(I,k2);          %apply kernels
    I = I - bwhitmiss(I,k3);

    I = I - bwhitmiss(I,rot90(k2));   % apply rotated kernels
    I = I - bwhitmiss(I,rot90(k3));

    I = I - bwhitmiss(I,rot90(k2,2));
    I = I - bwhitmiss(I,rot90(k3,2));

    I = I - bwhitmiss(I,rot90(k2,3));
    I = I - bwhitmiss(I,rot90(k3,3));
    
    subplot(1,3,2)
    imagesc(I)
    title(['Filtered Image' 'N = ' num2str(k)])
    subplot(1,3,3)
    imagesc(Ior-I)
    title("Difference Image")
    drawnow
    pause(0.5)
end



% use bwmorph to compute skelethon
figure('NumberTitle', 'off', 'Name', 'Esempio bwmorph');
axis image
colormap gray
BW3 = bwmorph(Ior,'skel',Inf);
subplot(1,2,1)
imagesc(Ior)
title("Original Image")
subplot(1,2,2)
imagesc(BW3)
title("Skelethon")

% use bwdist to compute distance map
figure('NumberTitle', 'off', 'Name', 'Esempio bwdist');
D = bwdist(1-Ior,'cityblock');
colormap gray
subplot(1,2,1)
imagesc(Ior)
title("Original Image")
subplot(1,2,2)
imagesc(D)
title("Distance Map")

figure('NumberTitle', 'off', 'Name', 'Distance Map');
surface(D)



