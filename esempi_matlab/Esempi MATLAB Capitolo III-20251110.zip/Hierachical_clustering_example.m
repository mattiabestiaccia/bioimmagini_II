% Hierarchical Clustering demonstration
close all
clear all

% create images with different noise levels
dim=256;
image=zeros(dim);
image(:)=20;
image(100:200,100:200)=200;
N=10; % number of images
X=zeros(N,dim,dim);
figure
noise=randperm(N).^2; % noise on images (random order)
for i=1:N
    subplot(2,5,i)
    colormap gray
    axis image
    X(i,:,:)=image+bias+noise(i).*randn(dim);
    imagesc(squeeze(X(i,:,:)))
    title(['image ', num2str(i),' noise = ',num2str(noise(i))])
end

XD=reshape(X,N,dim*dim); % vectorize images
D = pdist(XD); % compute distance matrix (significant terms, (N-1)+(N-2)+... = N(N-1)/2
Z = squareform(D); % distance matrix in NxN notation
Z

T=linkage(D,'single') % hierarchical clustering
figure
dendrogram(T) % display dendogram

figure
TC = cluster(T,'maxclust',3); % divide dendogram in three clusters
cutoff = median([T(end-2,3) T(end-1,3)]);
dendrogram(T,'ColorThreshold',cutoff)



% create images with different noise levels
dim=256;
image=zeros(dim);
image(:)=20;
image(100:200,100:200)=200;
N=10; % number of images
X=zeros(N,dim,dim);
figure
noise=10;
bias=5*(rand(1,N) > 0.5); % apply random bias between images
for i=1:N
    subplot(2,5,i)
    colormap gray
    axis image
    X(i,:,:)=image+bias(i)+noise*randn(dim);
    imagesc(squeeze(X(i,:,:)))
    title(['image ', num2str(i),' bias = ',num2str(bias(i))])
end

XD=reshape(X,N,dim*dim); % vectorize images
D = pdist(XD); % compute distance matrix (significant terms, (N-1)+(N-2)+... = N(N-1)/2
Z = squareform(D); % distance matrix in NxN notation
Z

T=linkage(D,'average') % hierarchical clustering
figure
dendrogram(T) % display dendogram

figure
TC = cluster(T,'maxclust',2); % divide dendogram in two clusters
cutoff = median([T(end-1,3) T(end,3)]);
dendrogram(T,'ColorThreshold',cutoff)


