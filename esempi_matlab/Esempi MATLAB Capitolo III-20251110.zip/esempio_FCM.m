close all
clear all

image = zeros(512,512);

image(:,:) = 20 ;
image(50:100,50:100)= 150;
image(101:180,101:450)= 300;
image(200:500,200:350)= 70;
image(230:270,230:270)= 750;
image(5:400,450:500)= 550;

sigma =10;

imageN= image + sigma*randn(512,512); 

kernel = ones(5)/25.0;
imageNS = conv2(imageN,kernel,'same');

colormap gray
imagesc(imageNS)

[center,U,J] = fcm(imageNS(:),6);

center

Umap = reshape(U,6,512,512);

figure
colormap gray
subplot(2,3,1)
imagesc(squeeze(Umap(1,:,:)))
subplot(2,3,2)
imagesc(squeeze(Umap(2,:,:)))
subplot(2,3,3)
imagesc(squeeze(Umap(3,:,:)))
subplot(2,3,4)
imagesc(squeeze(Umap(4,:,:)))
subplot(2,3,5)
imagesc(squeeze(Umap(5,:,:)))
subplot(2,3,6)
imagesc(squeeze(Umap(6,:,:)))
