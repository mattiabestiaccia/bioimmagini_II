close all
clear all

image=dicomread('phantom.dcm'); % load phantom image
image=double(image);
sz=size(image);

% display phantom image and image histogram 
figure('NumberTitle', 'off', 'Name', 'Fantoccio MR');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(image)
subplot(1,2,2)
[h edges]=histcounts(image(:));
x = edges(1:end-1)+ diff(edges)/2;
plot(x,h)


% manual segmentation of water signal
% from the image histogram we found 200 and 600 thresholds    
% create water mask
mask=zeros(size(image));
id = find ((image >200) & (image< 600)); % water pixels
mask(id)=255;
figure('NumberTitle', 'off', 'Name', 'Maschera acqua manuale');
axis('image') % preserve image proportions
imagesc(mask)
colormap gray

% Otsu algorithm
figure('NumberTitle', 'off', 'Name', 'Algoritmo di Otsu');
axis('image') % preserve image proportions
subplot(1,4,1)
colormap gray
[h edges]=histcounts(image(:)); % calculate image histogram
x = edges(1:end-1)+ diff(edges)/2; % x are centers of bins
plot(x,h)  % display histogram
[T,EM] = otsuthresh(h);  % calcualte threshold T (0:1)
Th=T*max(image(:)) % calculate image signal threshold
BW1 = imbinarize(image,Th); %create mask by imbinarize function
subplot(1,4,2)
imagesc(BW1)
image8bit=rescale(image,0,255); % graythresh designed for 8 bit images, rescale image to 8 bit
[level,EM] = graythresh(image8bit) % apply Otsu on 8bit image
Th1=level*max(image8bit(:))
BW = imbinarize(image8bit,Th1); %create mask by imbinarize function
subplot(1,4,3)
imagesc(BW)
[level,EM] = multithresh(image8bit,2) % apply multi-threshold Otsu on 8bit image
Th2=level
BW = imquantize(image8bit,Th2); %create masks by imquantize function
subplot(1,4,4)
imagesc(BW)


%kmeans clustering
figure('NumberTitle', 'off', 'Name', 'Algoritmo Kmeans');
axis('image') % preserve image proportions
[idx C]=kmeans(image(:),3);  % apply kmeans, we choice 3 clusters from the histogram shape
imagesc(reshape(idx,sz(1),sz(2))) % display cluster maps, in color
C=sort(C); % order centroids 
T = [mean(C(1:2))   mean(C(2:3))]  % equivalent Thresholds


% fuzzy C-means
[Cfcm U]=fcm(image(:),3); % apply FCM, we choice 3 clusters from the histogram shape
figure('NumberTitle', 'off', 'Name', 'Algoritmo FCM');
axis('image') % preserve image proportions
subplot(1,3,1)  
colormap gray
imagesc(reshape(U(1,:,:),sz(1),sz(2))) % display first component
subplot(1,3,2)
colormap gray
imagesc(reshape(U(2,:,:),sz(1),sz(2))) % display second component
subplot(1,3,3)
colormap gray
imagesc(reshape(U(3,:,:),sz(1),sz(2))) % display third component

figure('NumberTitle', 'off', 'Name', 'Algoritmo FCM - Profili');
U1=reshape(U(1,:,:),sz(1),sz(2));  % 
U2=reshape(U(2,:,:),sz(1),sz(2));  % 
U3=reshape(U(3,:,:),sz(1),sz(2));  % 
subplot(1,4,1)
colormap gray
tmp=image;
tmp(128,:)=1000;
imagesc(tmp)
subplot(1,4,2)  
plot(U1(128,:)) % plot profile
subplot(1,4,3)  
plot(U2(128,:)) % plot profile
subplot(1,4,4)  
plot(U3(128,:)) % plot profile





