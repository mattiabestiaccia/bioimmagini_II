% Gaussian mixture example

close all
clear all

%create a 3-tissues phantom (ideal image mask)
dim=512; % image dimension
tissueMask = zeros(dim,dim);
tissueMask(:,:) = 1 ;
tissueMask(50:190,50:190)= 2;
tissueMask(200:500,200:350)= 3;

figure('NumberTitle', 'off', 'Name', 'Maschera Fantoccio 3 tessuti');
axis('image') % preserve image proportions
colormap gray
imagesc(tissueMask)

% create three gaussian distributions
m1 =50   % mean
m2 =400
m3 =200
sd1 =60  % sd 
sd2 =40
sd3 =20
data1 = m1+sd1*randn(dim,dim); % signal distribution
data2 = m2+sd2*randn(dim,dim);
data3 = m3+sd3*randn(dim,dim);
id1  =find(tissueMask == 1) ;  % tissues masks 
id2  =find(tissueMask == 2) ;
id3  =find(tissueMask == 3) ;
image=zeros(dim);
image(id1) = data1(id1) ;      % create real image  
image(id2) = data2(id2) ;
image(id3) = data3(id3) ;

figure('NumberTitle', 'off', 'Name', 'Fantoccio 3 tessuti');
axis('image') % preserve image proportions
colormap gray
imagesc(image)

% probability of a tissue in the image (tissue pixels/total pixels) 
p1= length(id1)/length(image(:)) 
p2= length(id2)/length(image(:))
p3= length(id3)/length(image(:))

%calculate histogram
figure('NumberTitle', 'off', 'Name', 'Istogramma fantoccio');
subplot(1,3,1)
X=image(:);
[h edges]=histcounts(X);
x = edges(1:end-1)+ diff(edges)/2;
plot(x,h)


% apply EM-GMM to model histogram data
[idx,C] = kmeans(X,3); % find an initial guess for EM-GMM
subplot(1,3,2)
imagesc(reshape(idx,dim,dim))
%apply EM-GMM
GM=fitgmdist(double(X),3,'Options',statset('Display','iter'),'start',idx)

GM.mu           % mean values of Guassians
sqrt(GM.Sigma)  % SD of Gaussians

% calcualte histogram from EM.GMM
dataGM1 = GM.mu(1)+sqrt(GM.Sigma(1))*randn(1,fix(GM.PComponents(1)*length(X(:))));
dataGM2 = GM.mu(2)+sqrt(GM.Sigma(2))*randn(1,fix(GM.PComponents(2)*length(X(:))));
dataGM3 = GM.mu(3)+sqrt(GM.Sigma(3))*randn(1,fix(GM.PComponents(3)*length(X(:))));
dataGM = [dataGM1,dataGM2,dataGM3];

subplot(1,3,3)
%compare histograms
plot(x,h)
[hGM edgesGM]=histcounts(dataGM);
xGM = edgesGM(1:end-1)+ diff(edgesGM)/2;
hold on
plot(xGM,hGM,'r')




