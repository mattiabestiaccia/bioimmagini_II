% example connected three

close all
clear all

% create a 8-pattern image
image = zeros(7);
map=zeros(7); % pattern map
image(:)=1; % background

image(2:3,4)=2; 
map(2:3,4)=2;
image(6,4:6)=2;
image(5,4)=2;
map(6,4:6)=3;
map(5,4)=3;

image(2:3,2:3)=3;
map(2:3,2:3)=4;
image(2:3,5)=3;
image(4,6)=3;
map(2:3,5)=5;
map(4,6)=5;
image(5,2:3)=3;
image(6,3)=3;
map(5,2:3)=6;
map(6,3)=6;

image(2:3,6)=4;
map(2:3,6)=7;
image(6,2)=4;
map(6,2)=8;

id=find(image ==1);
map(id)=1;

figure('NumberTitle', 'off', 'Name', 'Connected tree');
s1=subplot(1,2,1);
axis image
imagesc(image)
colormap(s1,'gray');
title('image')

s2=subplot(1,2,2);
axis equal
imagesc(map)
colormap(s2,'jet');
title('map')

%connected tree
 
names={'c1' 'c2' 'c3' 'c4' 'c5' 'c6' 'c7' 'c8'}'; % node names
levels=[1 2 2 3 3 3 4 4]'; % gray levels for patterns
pixels=zeros(8,64);                               % pattern pixels for each node  (64 > totla number of pixels)       
for i=1:8
   id=find(map == i); % pixels coordinates for the i-th pattern
   pixels(i,1:length(id))=id; % write pixel coordinates in pixel list
end
 
NodeTable = table(names,levels,pixels,'VariableNames',{'Name' 'Level' 'Pixels'})

A=zeros(8,8); % adjacency matrix
A(1,2)=1; % c1-c2 connection
A(1,3)=1; % c1-c3 connection
A(2,4)=1;A(2,5)=1;A(5,7)=1;A(3,6)=1;A(6,8)=1;

G = digraph(A,NodeTable); % build graph
figure
plot(G)

 % we have the image coded in the graph
 
 v = dfsearch(G,1); % nodes order (depth-first search)
 lev=G.Nodes.Level; % levels
 
 list=lev(v);
 [v list [diff(list)' 0]']  % nodes and levels
 
 id=find(diff(list) < 0)  % find the two main part of tree  (change of level)
 
 Mpattern1 = v(2:id)      % first part
 G.Nodes.Name(Mpattern1)
 
 Mpattern2 = v(id+1:end) %second part
 G.Nodes.Name(Mpattern2)
 
 Mp1_pixels=[]; % pixel list of first part
 for i=1:length(Mpattern1)
    Mp1_pixels=[Mp1_pixels G.Nodes.Pixels(Mpattern1(i),:)];
 end
 Mp1_pixels=Mp1_pixels(find(Mp1_pixels ~=0)); %eliminate zero-padding in table
 
 Mp2_pixels=[]; % pixel list of second part
 for i=1:length(Mpattern2)
    Mp2_pixels=[Mp2_pixels G.Nodes.Pixels(Mpattern2(i),:)];
 end
 Mp2_pixels=Mp2_pixels(find(Mp2_pixels ~=0)); %eliminate zero-padding in table
 
 map1=zeros(7)
 map1(Mp1_pixels)=1;
 map1(Mp2_pixels)=2;

 figure
axis equal
imagesc(map1)
 
TR = shortestpath(G,2,7)

figure
plot(TR)

 
