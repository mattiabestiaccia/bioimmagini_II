%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Vincenzo Positano (vincenzo.positano@ing.unipi.it)
%%% materiale di supporto al corso di Bioimmagini
%%% esempio Mutual Information
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear all

% create incorrelate images (noise)
A = 255*rand(256) ;
B = 255*rand(256) ; 

figure('Name','Random Images')
colormap gray
subplot(1,2,1)
imagesc(A)
axis image
subplot(1,2,2)
imagesc(B)
axis image

%evaluate MI and RMSE
bins=32;
[miRand, jh1 ,locs] = mutualInformation(A,B,bins) ;
disp(['MI Random= ' num2str(miRand)])
rmseRand = sqrt(meansqr(A-B));
disp(['RMSE Random= ' num2str(rmseRand)])

figure
set(gcf,'numbertitle','off','name','2D Histogram Random Images')
colormap gray
bar3(jh1) ;
str = sprintf('MI = %f ',miRand);
title(str);


% create equal images
A= 255* (checkerboard > 0.5);
B= 255* (checkerboard > 0.5); 

figure('Name','Equal Images')
colormap gray
subplot(1,2,1)
imagesc(A)
axis image
subplot(1,2,2)
imagesc(B)
axis image

[miEq, jh2 ] = mutualInformation(A,B,bins) ;
disp(['MI Equal = ' num2str(miEq)])
rmseEq = sqrt(meansqr(A-B));
disp(['RMSE Random= ' num2str(rmseEq)])

figure
set(gcf,'numbertitle','off','name','Equal Images')
colormap gray
bar3(jh2) ;
str = sprintf('MI = %f ',miEq);
title(str);


% create rotated images
A= 255* (checkerboard > 0.5);
B= rot90(255* (checkerboard > 0.5)); 

figure('Name','Corr Images')
colormap gray
subplot(1,2,1)
imagesc(A)
axis image
subplot(1,2,2)
imagesc(B)
axis image

rmseRot = sqrt(meansqr(A-B));
disp(['RMSE Corr= ' num2str(rmseRot)])

[miRot, jh2 ] = mutualInformation(A,B,bins) ;
disp(['MI Corr = ' num2str(miRot)])

figure
set(gcf,'numbertitle','off','name','Corr Images')
colormap gray
bar3(jh2) ;
str = sprintf('MI = %f ',miRot);
title(str);



%shifted images
A= 255* (checkerboard > 0.5);
B= circshift((255* (checkerboard > 0.5)),8); 


figure('Name','Different Images')
colormap gray
subplot(1,2,1)
imagesc(A)
axis image
subplot(1,2,2)
imagesc(B)
axis image

rmse = sqrt(meansqr(A-B));
disp(['RMSE Diff = ' num2str(rmse)])

[mi, jh3 ] = mutualInformation(A,B,bins) ;
disp(['MI Diff = ' num2str(mi)])

figure
set(gcf,'numbertitle','off','name','Noisy Images')
colormap gray
bar3(jh3) ;
str = sprintf('MI = %f ',mi);
title(str);

% add noise
A= 255* (checkerboard > 0.5)+100*rand(80);
B= circshift((255* (checkerboard > 0.5)),8)+100*rand(80); 
% B = circshift(B,2,2);

figure('Name','Different Images')
colormap gray
subplot(1,2,1)
imagesc(A)
axis image
subplot(1,2,2)
imagesc(B)
axis image

rmse = sqrt(meansqr(A-B));
disp(['RMSE Diff = ' num2str(rmse)])

[mi, jh3 ] = mutualInformation(A,B,bins) ;
disp(['MI Diff = ' num2str(mi)])

figure
set(gcf,'numbertitle','off','name','Noisy Images')
colormap gray
bar3(jh3) ;
str = sprintf('MI = %f ',mi);
title(str);





