% compute the mutual information between two images of the same size
% works only if images are perfectly aligned
function [MI,hRF,locs] = mutualInformation(I1,I2,BINS)

v1  = I1(:) ; 
v2  = I2(:)  ;

sz = size(v1) ;
nP = sz(1) ; % number of pixels in the images

hR=hist(v1,BINS)/nP; % normalized histogram of the first image
hF=hist(v2,BINS)/nP; % normalized histogram of the second image

[hRF ,locs] = hist3([v1 v2],[BINS BINS]); % normalized joint histogram 
hRF = hRF/nP;

nz = find(hR ~= 0);
HR = - sum(log(hR(nz)).*hR(nz)); % entropy of the first image
nz = find( hF ~= 0);
HF = - sum(log(hF(nz)).*hF(nz)); % entropy of the second image
   
nz = find( hRF ~= 0);
HRF = - sum(log(hRF(nz)).*hRF(nz)); % joint entropy

MI = HR+HF-HRF; ;  % mutual information

end
  