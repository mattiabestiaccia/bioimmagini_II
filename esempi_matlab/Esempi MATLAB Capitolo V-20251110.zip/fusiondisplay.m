%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Vincenzo Positano (vincenzo.positano@ing.unipi.it)
%%% materiale di supporto al corso di Bioimmagini 
%%% esempio image fusion
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all
close all

%load images
image1=double(dicomread('REF.dcm'));
image2=double(dicomread('FLT.dcm'));

%display images
figure('NumberTitle', 'off', 'Name', 'Images to combine');
axis('image') % preserve image proportions
colormap gray
subplot(1,2,1)
imagesc(image1)
subplot(1,2,2)
imagesc(image2)

figure('NumberTitle', 'off', 'Name', 'imshowpair');
axis('image') % preserve image proportions
subplot(1,3,1)
tmp=image1;
tmp(:)=0;
imshowpair(tmp,image2)
title('First image')
subplot(1,3,2)
tmp=image2;
tmp(:)=0;
imshowpair(image1,tmp)
title('Second image')
subplot(1,3,3)
imshowpair(image1,image2)
title('Combined images')


figure('NumberTitle', 'off', 'Name', 'imfuse');
axis('image') % preserve image proportions
subplot(2,2,1)
img= imfuse(image1,image2,'method','falsecolor');
imagesc(img)
title('falsecolor')
subplot(2,2,2)
img= imfuse(image1,image2,'method','blend');
imagesc(img)
colormap gray
title('blend')
subplot(2,2,3)
img= imfuse(image1,image2,'method','checkerboard');
imagesc(img)
title('checkerboard')
subplot(2,2,4)
img= imfuse(image1,image2,'method','diff');
imagesc(img)
title('diff')



