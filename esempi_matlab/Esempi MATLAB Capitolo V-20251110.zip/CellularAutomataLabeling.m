% cellula automata example (mask)
close all
clear all
clc


% generate binary image
N=64; % image dimension
img =zeros(N,N);
img(N/4:N/2,N/4:N-1)=255;

figure
colormap gray
imagesc(img)

K=2 ; % number of labels (2:object, 1:background)

I=zeros(N,N) ; % state (2:object,1:background)
Th=zeros(N,N) ; % strenght
C = img ; % feature (gray level)

I(:,:)=1;             % define itial value of state I
I(20,20) = 2 ;        % seed
Th(20,20) = 1 ;       % define ititial strength


hFig=figure(1);
set(hFig, 'Position', [300 500 1500 500])
subplot(1,4,1)
colormap gray
imagesc(img)
axis image
set(gca,'xtick',[],'ytick',[])
title('Image')

Niter = 80 ; % number of iterations
d=1; % kernel size
maxC = max(C(:)); %image range
iter=1;
while(iter < Niter)  % iterations
  I_new = I ;        
  Th_new = Th;  
  for i=2: N-1       % exclude borders
    for j=2:N-1
        Th_Q = Th(i-d:i+d,j-d:j+d); % local strenght (Moore kernel)
        I_Q = I(i-d:i+d,j-d:j+d);   % local state
        C_Q = abs(C(i-d:i+d,j-d:j+d)-C(i,j)); % fit function
        fit = (1 - C_Q/maxC).*Th_Q;
        sumT=0;        % cumpute new state and stength
        for q=1:2*d+1   
            for w=1:2*d+1
                if (fit(q,w) > Th(i,j))         % update if needed
                    I_new(i,j) = I_Q(q,w);
                    Th_new(i,j) = Th_Q(q,w)*(1 - C_Q(q,w)/maxC);
                end
            end
        end
    end
  end
  I=I_new;      % restore backup
  Th=Th_new;
  iter
  
  
  colormap gray;
  subplot(1,4,2)
  imagesc(I);
  axis image
  set(gca,'xtick',[],'ytick',[])
  title('Segmentation')
  colormap gray;
  
  subplot(1,4,3)
  imagesc(Th);
  axis image
  set(gca,'xtick',[],'ytick',[])
  colormap gray;
  title('T strengt map')
  
  subplot(1,4,4)
  %imagesc(255*I/2-img);
  imshowpair(img,I)
  axis image
  set(gca,'xtick',[],'ytick',[])
  pause(0.5)
  
  drawnow
  iter=iter+1;
  
  
end