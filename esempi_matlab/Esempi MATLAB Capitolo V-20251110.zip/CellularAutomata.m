% cellular automata example
%% 
close all
clear all
clc


% generate image
N=64; % image dimension
img =zeros(N,N);
img(N/4:N/2,N/4:N)=255; 
img = img + 20*randn(N); % add noise

img1=img(:);
hFig=figure(1)
set(hFig, 'Position', [300 500 1500 500])

%display image
subplot(1,4,1)
colormap gray
imagesc(img)
axis image
title('image')
set(gca,'xtick',[],'ytick',[])
%% 

%initialize algorithm
K=3 ; % number of labels (2:object, 1:neutral, 0:background)
I=zeros(N,N) ; % state (2:object, 1:neutral, 0:background)
I(:,:)=1;
Th=zeros(N,N) ; % strenght
[Gmag,Gdir] = imgradient(img); %calculate gradient
C = Gmag ; % feature is module of image gradient

id = find(Gmag > 1000);     % define seed in high gradient region
I(id(17))  = 2 ;             % set as object a large gradient pixel 
Th(id(17)) = 1;              % set the seed with a non-zero strenght 
id = find(Gmag <60);        % seed in low gradient region
I(id(40))  = 0 ;             % set as background a low gradient pixel
Th(id(40)) = 1;              % set the seed wiht a non-zero strenght 

Niter = 500 ; % number of iterations
d=1; % kernel size
maxC = max(C(:));
iter=1;
while(iter < Niter)
  I_new = I ;
  Th_new = Th;  
  for i=2: N-1
    for j=2:N-1
        Th_Q = Th(i-d:i+d,j-d:j+d);  % local strength (Moore kernel)
        I_Q = I(i-d:i+d,j-d:j+d);    % local status
        C_Q = abs(C(i-d:i+d,j-d:j+d)-C(i,j)); % compute fit
        fit = (1 - C_Q/maxC).*Th_Q;
        sumT=0;
        for q=1:2*d+1
            for w=1:2*d+1
                if (fit(q,w) > Th(i,j))     % update if needed
                    I_new(i,j) = I_Q(q,w);
                    Th_new(i,j) = Th_Q(q,w)*(1 - C_Q(q,w)/maxC);
                    sumT = sumT+Th_new(i,j);
                end
            end
        end
    end
  end

  I=I_new;
  Th=Th_new;
  iter
  
  
  colormap gray;
  subplot(1,4,2)
  imagesc(I);
  axis image
  title('state')
  set(gca,'xtick',[],'ytick',[])

  
  colormap gray;
  subplot(1,4,3)
  imagesc(Th);
  axis image
  title('strenght')
  set(gca,'xtick',[],'ytick',[])
  
  subplot(1,4,4)
  imshowpair(img,I)
  
  drawnow
  if (iter <100) 
      pause(0.5)
  end
  iter=iter+1;
  
  
end