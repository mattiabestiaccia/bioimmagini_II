% genetic algorithm demonstation
close all
clear all

% rastrigins function is a test function for optimizators (several local
% minima
rf3 = @(x,y)reshape(rastriginsfcn([x(:)/10,y(:)/10]),size(x));
fsurf(rf3,[-30 30],'ShowContours','on')
title('rastriginsfcn([x/10,y/10])')
xlabel('x')
ylabel('y')

% monodimensional version
rf2 = @(x)rastriginsfcn(x/10);

% exaustive search
dx=0.1;
i=1;
clear ras
for x=-30:dx:30
    ras(i)=rf2(x);
    i=i+1;
end
plot(-30:dx:30,ras)
min(ras(:))


% local optimization
x0 = -3; % start point away from the minimum
[xf,ff,flf,of] = fminunc(rf2,x0)


% global MultiStart
opts = optimoptions(@fminunc);
problem = createOptimProblem('fminunc','objective',...
    rf2,'x0',-15,'lb',-30,'ub',30,'options',opts);
ms = MultiStart;
[x,f] = run(ms,problem,200)


%global GA
x0 = -15; % start point away from the minimum
initpop = 10*randn(20,2) + repmat(x0,20,1);
opts = optimoptions('ga','PlotFcn', @gaplotrange,'InitialPopulationMatrix',initpop,'MaxGenerations',500);
[xga,fga,flga,oga] = ga(rf2,2,[],[],[],[],[],[],[],opts)



