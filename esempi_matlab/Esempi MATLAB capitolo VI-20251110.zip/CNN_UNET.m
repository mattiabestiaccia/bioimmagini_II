%% CNN U-NET
%% exemplification of the use of a U-NET network for image segmentation
%%

close all
clear all

dataSetDir = fullfile('TEST3'); % define data path
imageDir = fullfile(dataSetDir,'C1');  % images to segment
labelDir = fullfile(dataSetDir,'C2');  % segmentation labels

imds = imageDatastore(imageDir,'LabelSource','foldernames'); % create image datastore
N=length(imds.Files); % number of images

classNames = ["pattern","background"];  % pixel classes
labelIDs   = [255 0];                   % label classes (segmentation labels must have pattern=255, back=0     

pxds = pixelLabelDatastore(labelDir,classNames,labelIDs); % create labels datastore

%create training set 
trainingNumImages = 3*N/4; % 75% of images in the training set
perm = randperm(N); 
TrainingImages = imageDatastore(imds.Files(perm(1:trainingNumImages)));
TrainingLabels = pixelLabelDatastore(pxds.Files(perm(1:trainingNumImages)),classNames,labelIDs);
TrainingData=combine(TrainingImages,TrainingLabels);

%create test set
TestImages = imageDatastore(imds.Files(perm(trainingNumImages+1:end)));
TestLabels = pixelLabelDatastore(pxds.Files(perm(trainingNumImages+1:end)),classNames,labelIDs);
TestData=combine(TestImages,TestLabels);

%Display some of the images in the training data. 
figure;
perm = randperm(trainingNumImages,10);
j=1;
for i = 1:10
    subplot(5,4,j);
    imshow(TrainingImages.Files{perm(i)});
    subplot(5,4,j+1);
    imshow(TrainingLabels.Files{perm(i)});
    j=j+2;
end


% create network
tmpImg=readimage(pxds,1);
imageSize = size(tmpImg);  % must be 2^N (32 64 128 .....)
numClasses = length(classNames);
lgraph = unetLayers(imageSize, numClasses)
figure
analyzeNetwork(lgraph)


% train the network
options = trainingOptions('sgdm','InitialLearnRate',1e-3,'MaxEpochs',20,'VerboseFrequency',10,'Plots','training-progress');
net = trainNetwork(TrainingData,lgraph,options)

res = semanticseg(TrainingData,net,'MiniBatchSize',4,'WriteLocation',tempdir); % use trained network on training data
metrics = evaluateSemanticSegmentation(res,TrainingLabels,'Metric','all'); % evaluate performance on training data
metrics.ConfusionMatrix

%Display some of the results in the datastore. 

gt=zeros(imageSize(1),imageSize(2),trainingNumImages);
est=zeros(imageSize(1),imageSize(2),trainingNumImages);
for i = 1:trainingNumImages
    img_gt=readimage(TrainingLabels,i);
    tmp=zeros(imageSize);
    id=find(img_gt == classNames(1));
    tmp(id)=255;
    gt(:,:,i)=tmp;
    img_est=readimage(res,i);
    tmp=zeros(imageSize);
    id=find(img_est == classNames(1));
    tmp(id)=255;
    est(:,:,i)=tmp;
end

figure;
perm = randperm(trainingNumImages,10);
j=1;
for i = 1:10
    subplot(5,4,j);
    imagesc(squeeze(gt(:,:,i)));
    subplot(5,4,j+1);
    imagesc(squeeze(est(:,:,i)));
    j=j+2;
end



figure;
perm = randperm(trainingNumImages,20);
for i = 1:20
    subplot(4,5,i);
    imshowpair(gt(:,:,perm(i)),est(:,:,perm(i)))
end


%%%%% test data analysis

res = semanticseg(TestData,net,'MiniBatchSize',4,'WriteLocation',tempdir); % use trained network on test data
metrics = evaluateSemanticSegmentation(res,TestLabels,'Metric','all'); % evaluate performance on training data
metrics.ConfusionMatrix

%Display some of the results in the datastore. 
testNumImages=N-trainingNumImages
gt=zeros(imageSize(1),imageSize(2),testNumImages);
est=zeros(imageSize(1),imageSize(2),testNumImages);
for i = 1:testNumImages
    img_gt=readimage(TestLabels,i);
    tmp=zeros(imageSize);
    id=find(img_gt == classNames(1));
    tmp(id)=255;
    gt(:,:,i)=tmp;
    img_est=readimage(res,i);
    tmp=zeros(imageSize);
    id=find(img_est == classNames(1));
    tmp(id)=255;
    est(:,:,i)=tmp;
end

figure;
perm = randperm(testNumImages,10);
j=1;
for i = 1:10
    subplot(5,4,j);
    imagesc(squeeze(gt(:,:,i)));
    subplot(5,4,j+1);
    imagesc(squeeze(est(:,:,i)));
    j=j+2;
end



figure;
perm = randperm(testNumImages,20);
for i = 1:20
    subplot(4,5,i);
    imshowpair(gt(:,:,perm(i)),est(:,:,perm(i)))
end

