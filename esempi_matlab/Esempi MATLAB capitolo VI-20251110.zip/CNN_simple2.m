%% CNN classifier

close all
clear all
digitDatasetPath = fullfile('TEST2'); % define data path
% data stored in separate folders, folders names indicate the classes 
% |imageDatastore| function labels the images automatically based on folder
% names and stores the data as an |ImageDatastore| object. An
% |ImageDatastore| object lets you store large image data, including data
% that do not fit in memory, and efficiently read batches of images during
% training of a convolutional neural network.

allData = imageDatastore(digitDatasetPath,'IncludeSubfolders',true,'LabelSource','foldernames');  % read data

%% 
%Display some of the images in the datastore. 
figure;
perm = randperm(2000,20);
for i = 1:20
    subplot(4,5,i);
    imshow(allData.Files{perm(i)});
end

CountLabel = allData.countEachLabel % Check the number of images in each category.

%% 
% You must specify the size of the images in the input layer of the
% network. Check the size of the first image in |digitData| .
img = readimage(allData,1);
sz=size(img)

%%

%% Specify Training and Test Sets
% Divide the data into training and test sets, so that each category in the
% training set has 3/4 images and the test set has the remaining images
% from each label.
N = table2array(CountLabel(1,2)) % number of data

testNumImages = 100;
valNumImages = 100;
trainingNumImages = N-testNumImages-valNumImages;

[trainImageData,valImageData,testImageData] = splitEachLabel(allData,trainingNumImages,valNumImages,testNumImages,'randomize'); 

% perform classification by CNN


layers = [imageInputLayer([28 28 1])  
          convolution2dLayer(7,8,'Padding','same')
          reluLayer
          maxPooling2dLayer(2,'Stride',2)
          convolution2dLayer(7,8,'Padding','same')
          reluLayer
          maxPooling2dLayer(2,'Stride',2)
          convolution2dLayer(7,8,'Padding','same')
          reluLayer
          maxPooling2dLayer(2,'Stride',2)
          convolution2dLayer(7,8,'Padding','same')
          reluLayer
          maxPooling2dLayer(2,'Stride',2)
          fullyConnectedLayer(2)
          softmaxLayer
          classificationLayer()];  


options = trainingOptions('sgdm','MaxEpochs',150,'InitialLearnRate',0.0001, 'Plots','training-progress','ValidationData',valImageData);
convnet = trainNetwork(trainImageData,layers,options);

YTrain = classify(convnet,trainImageData);
Ttrain= trainImageData.Labels;
plotconfusion(Ttrain,YTrain); % confusion matrix



% test set
Ytest = classify(convnet,testImageData);
Ttest= testImageData.Labels;
plotconfusion(Ttest,Ytest); % confusion matrix


tf = activations(convnet,trainImageData,3); % 28x28x8x1500
size(tf)

figure
colormap gray
subplot(2,2,1)
imagesc(squeeze(tf(:,:,1,1)))
title('Croce filtro 1')
axis equal
subplot(2,2,2)
imagesc(squeeze(tf(:,:,1,1300)))
title('Rettangolo filtro 1')
axis equal
subplot(2,2,3)
imagesc(squeeze(tf(:,:,4,1)))
title('Croce filtro 4')
axis equal
subplot(2,2,4)
imagesc(squeeze(tf(:,:,4,1300)))
title('Rettangolo filtro 4')
axis equal


tf = activations(convnet,trainImageData,6); % 28x28x8x1500
size(tf)

figure
colormap gray
subplot(2,2,1)
imagesc(squeeze(tf(:,:,1,1)))
title('Croce filtro 1')
axis equal
subplot(2,2,2)
imagesc(squeeze(tf(:,:,1,1000)))
title('Rettangolo filtro 1')
axis equal
subplot(2,2,3)
imagesc(squeeze(tf(:,:,4,1)))
title('Croce filtro 4')
axis equal
subplot(2,2,4)
imagesc(squeeze(tf(:,:,4,1000)))
title('Rettangolo filtro 4')
axis equal


tf = activations(convnet,trainImageData,8); % softmax
size(tf)

C1=mean(tf(1,1,1,1:750))
R1=mean(tf(1,1,1,751:end))

C2=mean(tf(1,1,2,1:750))
R2=mean(tf(1,1,2,751:end))

figure
plot([C1 R1],[C2 R2],'o')
% xlim([-20 20])
% ylim([-20 20])






