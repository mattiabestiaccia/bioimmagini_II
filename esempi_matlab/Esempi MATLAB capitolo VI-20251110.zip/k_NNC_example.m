%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% KNC example
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear all

% training/test data
syntheticDir   = fullfile(toolboxdir('vision'), 'visiondata','digits','synthetic');
handwrittenDir = fullfile(toolboxdir('vision'), 'visiondata','digits','handwritten');

% |imageDatastore| recursively scans the directory tree containing the
% images. Folder names are automatically used as labels for each image.
trainingSet = imageDatastore(syntheticDir,   'IncludeSubfolders', true, 'LabelSource', 'foldernames'); 
testSet     = imageDatastore(handwrittenDir, 'IncludeSubfolders', true, 'LabelSource', 'foldernames');

countEachLabel(trainingSet)
countEachLabel(testSet)

numImages = numel(trainingSet.Files);
img = readimage(trainingSet, 1);
sz=size(img);

% divide the training set 
numVal=numImages/5;
numTrain=4*numImages/5;

trainImages = zeros(numTrain,sz(1),sz(2));
trainLabel=categorical(1,numTrain);
valImages = zeros(numVal,sz(1),sz(2));
valLabel=categorical(1,numVal);

list=randperm(numImages);

for i = 1:numTrain
    img = readimage(trainingSet, list(i));
    img = rgb2gray(img);
    trainImages(i,:,:)=img;
    trainLabel(i)=trainingSet.Labels(list(i));
end
for i = 1:numVal
    img = readimage(trainingSet, list(numTrain+i));
    img = rgb2gray(img);
    valImages(i,:,:)=img;
    valLabel(i)=trainingSet.Labels(list(numTrain+i));
end

% data example
figure;
k=floor(numTrain*rand())+1
subplot(1,2,1);
colormap gray
imagesc(squeeze(trainImages(k,:,:)));
title(trainLabel(k)) 

k=floor(numVal*rand())+1
subplot(1,2,2);
colormap gray
imagesc(squeeze(valImages(k,:,:)));
title(valLabel(k)) 


% NNC classifier
figure
colormap gray
lab=categorical(1,numVal);
for k=1:numVal
    img = squeeze(valImages(k,:,:)); % load image to classify
    dist=zeros(1,numTrain); % distance vector
    for i=1:numTrain
        imgT=squeeze(trainImages(i,:,:)); % load image from train set
        d(i)=sqrt(immse(img, imgT));      % SQRT metric    
    end
    [m id ]=min(d);                       % find the best match   
    lab(k)=trainLabel(id);
    imgMin=squeeze(trainImages(id,:,:));
    subplot(1,2,1)
    imagesc(img);
    title(lab(k));
    subplot(1,2,2)
    imagesc(imgMin);
    title(lab(k));
    drawnow
    %pause
end    

% measure accuracy in the training set
v= (lab == valLabel); 
accVal = 100*sum(v)/numVal;

% verify on the test set
numImagesTest = numel(testSet.Files);
img = readimage(testSet, 1);
szTest=size(img);

testImages = zeros(numImagesTest,sz(1),sz(2));
testLabel=categorical(1,numImagesTest);
for i = 1:numImagesTest
    img = readimage(testSet,i);
    img = rgb2gray(img);
    testImages(i,:,:)=img;
    testLabel(i)=testSet.Labels(i);
end

figure
colormap gray
lab=categorical(1,numVal);
for k=1:numImagesTest
    img = squeeze(testImages(k,:,:)); % load image to classify
    dist=zeros(1,numTrain); % distance vector
    for i=1:numTrain
        imgT=squeeze(trainImages(i,:,:)); % load image from train set
        d(i)=sqrt(immse(img, imgT));
    end
    [m id ]=min(d);
    lab(k)=trainLabel(id);
    imgMin=squeeze(trainImages(id,:,:));
    subplot(1,2,1)
    imagesc(img);
    title(testLabel(k));
    subplot(1,2,2)
    imagesc(imgMin);
    title(lab(k));
    drawnow
    pause
end 

v= (lab == testLabel); 
accTest = 100*sum(v)/numImagesTest;


%k-NCC
figure
colormap gray
lab=categorical(1,numImagesTest);
K=1;
for k=1:numImagesTest
    img = squeeze(testImages(k,:,:)); % load image to classify
    dist=zeros(1,numTrain); % distance vector
    for i=1:numTrain
        imgT=squeeze(trainImages(i,:,:)); % load image from train set
        d(i)=sqrt(immse(img, imgT));
    end
    [sTmp id] = sort(d);
    bestlabels=trainLabel(id(1:K))
    [N,edges] = histcounts(bestlabels);
    [m idm ]=max(N);
    bestLab=categorical(edges(idm))
    lab(k)=bestLab;
    
    %     imgMin=squeeze(trainImages(id,:,:));
%     subplot(1,2,1)
%     imagesc(img);
%     title(testLabel(k));
%     subplot(1,2,2)
%     imagesc(imgMin);
%     title(lab(k));
%     drawnow
%     pause
end 

v= (lab == testLabel); 
accTest = 100*sum(v)/numImagesTest;

