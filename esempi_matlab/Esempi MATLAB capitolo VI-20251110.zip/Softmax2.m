%% soft max classifier

close all
clear all

digitDatasetPath = fullfile('TEST2'); % define data path
% data stored in separate folders, folders names indicate the classes 
% |imageDatastore| function labels the images automatically based on folder
% names and stores the data as an |ImageDatastore| object. An
% |ImageDatastore| object lets you store large image data, including data
% that do not fit in memory, and efficiently read batches of images during
% training of a convolutional neural network.

testData = imageDatastore(digitDatasetPath,'IncludeSubfolders',true,'LabelSource','foldernames');  % read data

%% 
%Display some of the images in the datastore. 
figure;
perm = randperm(2000,20);
for i = 1:20
    subplot(4,5,i);
    imshow(testData.Files{perm(i)});
end

CountLabel = testData.countEachLabel % Check the number of images in each category.

%% 
% You must specify the size of the images in the input layer of the
% network. Check the size of the first image in |digitData| .
img = readimage(testData,1);
sz=size(img)

%%

%% Specify Training and Test Sets
% Divide the data into training and test sets, so that each category in the
% training set has 3/4 images and the test set has the remaining images
% from each label.
N = table2array(CountLabel(1,2)) % number of data
trainingNumImages = 3*N/4;
[trainImageData,testImageData] = splitEachLabel(testData,trainingNumImages,'randomize'); 

% perform classification
% net = trainSoftmaxLayer(X,T);
% X is a NxK matrix N: number of pixels K: number of data
%T is a CxK matrix. Each row corresponds to a dummy variable representing the class, a 1 in one of the rows represents the class that particular sample belongs to. There is a zero in the rows for the other classes that the observation does not belong to.

trainLabels= trainImageData.countEachLabel; %extract labels
K = table2array(trainLabels(1,2));
N=sz(1)*sz(2);
T=zeros(2,2*K);
T(1,1:K)=1;
T(2,K+1:end)=1;
X=zeros(N,2*K);
for i=1:2*K
    img=readimage(trainImageData,i);
    X(:,i)=img(:);
end

SoftMaxClass = trainSoftmaxLayer(X,T); % classification

% SoftMaxClass is a trained softmax classifier
Y = SoftMaxClass(X); % test the classifier on trainig data

plotconfusion(T,Y); % confusion matrix



% test set

testLabels= testImageData.countEachLabel; %extract labels
K = table2array(testLabels(1,2));
N=sz(1)*sz(2);
Ttest=zeros(2,2*K);
Ttest(1,1:K)=1;
Ttest(2,K+1:end)=1;
Xtest=zeros(N,2*K);
for i=1:2*K
    img=readimage(testImageData,i);
    Xtest(:,i)=img(:);
end

Ytest = SoftMaxClass(Xtest); % test the classifier on test data

plotconfusion(Ttest,Ytest); % confusion matrix











