%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Vincenzo Positano (vincenzo.positano@ing.unipi.it)
%%% materiale di supporto al corso di Bioimmagini 
%%% esempio Entropia dell'immagine biomedica
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all
clear all

BINS=64; % bins for histogram computation
dim=256; % image dimension
nE = 5 ; % number of examples

% random image
A = 255*rand(dim); ; % create noise image
nP=length(A(:));  % number of pixels
[hA ,locs]=hist(A(:),BINS); % normalized histogram of the image
hA=hA/nP;
nz = find(hA ~= 0); % zero values in histogram
HA = - sum(log(hA(nz)).*hA(nz)); % entropy of the image

figure
set(gcf,'numbertitle','off','name','Random Image')
colormap gray
subplot(nE,2,1)
imagesc(A)
axis image
subplot(nE,2,2)
bar(locs,hA)
str = sprintf('Entropy = %f ',HA);
title(str);


% one pattern image
A = 255*ones(dim);  % create noise image
nP=length(A(:));  % number of pixels
[hA ,locs]=hist(A(:),BINS); % normalized histogram of the image
hA=hA/nP;
nz = find(hA ~= 0); % zero values in histogram
HA = - sum(log(hA(nz)).*hA(nz)); % entropy of the image


set(gcf,'numbertitle','off','name','One pattern image')
colormap gray
subplot(nE,2,3)
imagesc(A)
axis image
subplot(nE,2,4)
bar(locs,hA)
str = sprintf('Entropy = %f ',HA);
title(str);

% two pattern image
A = 255*zeros(dim); ; % create noise image
A(100:200,100:200)=100;
nP=length(A(:));  % number of pixels
[hA ,locs]=hist(A(:),BINS); % normalized histogram of the image
hA=hA/nP;
nz = find(hA ~= 0); % zero values in histogram
HA = - sum(log(hA(nz)).*hA(nz)); % entropy of the image


set(gcf,'numbertitle','off','name','Two patterna image')
colormap gray
subplot(nE,2,5)
imagesc(A)
axis image
subplot(nE,2,6)
bar(locs,hA)
str = sprintf('Entropy = %f ',HA);
title(str);

% two pattern image + noise
A = 255*zeros(dim) ; % create noise image
A(100:200,100:200)=100;
A=A+10*randn(dim)
nP=length(A(:));  % number of pixels
[hA ,locs]=hist(A(:),BINS); % normalized histogram of the image
hA=hA/nP;
nz = find(hA ~= 0); % zero values in histogram
HA = - sum(log(hA(nz)).*hA(nz)); % entropy of the image


set(gcf,'numbertitle','off','name','Two patterna image + noise' )
colormap gray
subplot(nE,2,7)
imagesc(A)
axis image
subplot(nE,2,8)
bar(locs,hA)
str = sprintf('Entropy = %f ',HA);
title(str);

% two pattern image + PVE
A = 255*zeros(dim) ; % create noise image
A(100:200,100:200)=100;
A=imgaussfilt(A,10.0);
nP=length(A(:));  % number of pixels
[hA ,locs]=hist(A(:),BINS); % normalized histogram of the image
hA=hA/nP;
nz = find(hA ~= 0); % zero values in histogram
HA = - sum(log(hA(nz)).*hA(nz)); % entropy of the image


set(gcf,'numbertitle','off','name','Two patterna image + PVE')
colormap gray
subplot(nE,2,9)
imagesc(A)
axis image
subplot(nE,2,10)
bar(locs,hA)
str = sprintf('Entropy = %f ',HA);
title(str);




