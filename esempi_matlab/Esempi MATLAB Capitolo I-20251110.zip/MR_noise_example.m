% MR noise example 

clear all
close all

sigma=10; % noise SD
dim=256; % image dimension

% noise only (background)

imageR=sigma*randn(dim);  
imageI=sigma*randn(dim);

imageM=sqrt(imageR.^2+imageI.^2);

BINS=256;
[hR ,locsR]=hist(imageR(:),BINS); % histogram of the R image
[hI ,locsI]=hist(imageI(:),BINS); % histogram of the R image
[hM ,locsM]=hist(imageM(:),BINS); % histogram of the magnitude image

figure
set(gcf,'numbertitle','off','name','MR noise')
subplot(1,3,1)
bar(locsR,hR)
str = sprintf('Image R \n mean = %5.1f SD = %5.1f ',mean(imageR(:)),std(imageR(:)));
title(str);
subplot(1,3,2)
bar(locsI,hI)
str = sprintf('Image I \n mean = %5.1f SD = %5.1f ',mean(imageI(:)),std(imageI(:)));
title(str);
subplot(1,3,3)
bar(locsM,hM)
str = sprintf('Image M \n mean = %5.1f SD = %5.1f ',mean(imageM(:)),std(imageM(:)));
title(str);


% high SNR  (tissue)

imageR=100+sigma*randn(dim);  
imageI=100+sigma*randn(dim);

imageM=sqrt(imageR.^2+imageI.^2);

BINS=256;
[hR ,locsR]=hist(imageR(:),BINS); % histogram of the R image
[hI ,locsI]=hist(imageI(:),BINS); % histogram of the R image
[hM ,locsM]=hist(imageM(:),BINS); % histogram of the magnitude image

figure
set(gcf,'numbertitle','off','name','MR noise')
subplot(1,3,1)
bar(locsR,hR)
str = sprintf('Image R \n mean = %5.1f SD = %5.1f ',mean(imageR(:)),std(imageR(:)));
title(str);
subplot(1,3,2)
bar(locsI,hI)
str = sprintf('Image I \n mean = %5.1f SD = %5.1f ',mean(imageI(:)),std(imageI(:)));
title(str);
subplot(1,3,3)
bar(locsM,hM)
str = sprintf('Image M \n mean = %5.1f SD = %5.1f ',mean(imageM(:)),std(imageM(:)));
title(str);

