close all
clear all

% create ideal image with two patterns
dim=512;
image = zeros(dim,dim);
image(200:400,200:400)=255;

ksize=9;
h=ones(ksize)/(ksize^2);

figure('NumberTitle', 'off', 'Name', 'Gaussian Noise');
for i=1:100
    subplot(1,2,1)
    axis('image')
    colormap gray
    image1=image;
    image1(300,:)=500;
    imagesc(image1)
    subplot(1,2,2)
    p=image(300,:);
    plot(p,'r')
    image=imfilter(image,h,'replicate');
    drawnow
    pause(0.1)
end