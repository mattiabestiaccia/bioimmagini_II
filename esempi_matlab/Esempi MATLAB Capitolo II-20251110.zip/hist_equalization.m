% esempio equalizzazione

close all
clear all

I = double(dicomread('phantom_15.dcm')); % read CT phantom image
I = I-min(I(:))+1; % avoid negative values

p=max(I(:)); % image deep
N=size(I,1)*size(I,2); % number of pixels

hI=hist(I(:),p); % compute histogram of original image

CDF=(p/N)*cumsum(hI); % compute normalized CDF 

% plot original image, histogram, and CDF
figure
subplot(1,2,1)
colormap gray
axis image
imagesc(I)
set(gca,'xtick',[],'ytick',[]) % no number please
subplot(1,2,2)
plot(hI(2:end)/sum(hI(:))) % first value is zero padding 
hold on
plot(CDF(2:end)/(sum(hI(:))))


% apply equalization filter
for i=1:size(I,1)
    for j=1:size(I,2)
            Ieq(i,j)=N*CDF(I(i,j));
    end
end


hIeq=hist(Ieq(:),p); % compute histogram of filtered image

% plot images and histograms
figure
colormap gray
subplot(2,2,1)
imagesc(I)
set(gca,'xtick',[],'ytick',[]) % no number please
subplot(2,2,2)
plot(hI(2:end))
subplot(2,2,3)
imagesc(Ieq)
set(gca,'xtick',[],'ytick',[]) % no number please
subplot(2,2,4)
plot(hIeq(2:end))


% try MATLAB function
IeqMatlab = histeq(I); % Matlab filtered image
hIeqMatlab=hist(IeqMatlab(:),p); % compute histogram of filtered image

% plot images and histograms (don't work)
figure
colormap gray
subplot(2,2,1)
imagesc(I)
set(gca,'xtick',[],'ytick',[]) % no number please
subplot(2,2,2)
plot(hI(2:end))
subplot(2,2,3)
imagesc(IeqMatlab)
set(gca,'xtick',[],'ytick',[]) % no number please
subplot(2,2,4)
plot(IeqMatlab(2:end))

% much better but we will miss image dynamic
I8=mat2gray(I);
IeqMatlab = histeq(I8); % Matlab filtered image
hIeqMatlab=hist(IeqMatlab(:),p); % compute histogram of filtered image

% plot images and histograms (don't work)
figure
colormap gray
subplot(2,2,1)
imagesc(I8)
set(gca,'xtick',[],'ytick',[]) % no number please
subplot(2,2,2)
plot(hI(2:end))
subplot(2,2,3)
imagesc(IeqMatlab)
set(gca,'xtick',[],'ytick',[]) % no number please
subplot(2,2,4)
plot(IeqMatlab(2:end))


