% esercitazione super resolution
% esempio di effetto PVE (paragrafo super-resolution capitolo 2)

Nhr = 2048; % dimensione immagine alta risoluzione
Nlr=8;      % dimensione immagine bassa risoluzione
S1=1000;    % segnale tessuto
S2=100;     % segnale sfondo
R=128;      % raggio fantoccio circolare
Cx=Nhr/2+R; % centro fantoccio
Cy=Nhr/2+R;

% creazione immagine HR
% per pigrizia � lentissimo, se qualcuno lo fa in vettoriale me lo mandi,
% grazie
HRimage = zeros(Nhr,Nhr);
HRimage(:,:)=S2;
for i=1:Nhr
    for j=1:Nhr
        if pdist([[i j]; [Cx Cy]]) < R 
            HRimage(i,j)=S1;
        end
    end
end
   
% immagine HR
figure
axis equal
colormap gray
imagesc(HRimage)


%creiamo l'immagine a bassa risoluzione

LRimage = zeros(Nlr,Nlr);
inc=0; % sfasamento inc = 0 contrasto max, inc=256 contrasto minimo
% si suppone lo stesso sfasamento sui due assi
bl=Nhr/Nlr; % dimension pixel LR
for i=1:Nlr
    for j=1:Nlr
        ir=(i-1)*bl+1;
        jr=(j-1)*bl+1;
        %evitiamo di uscire dal dominio dell'immagine HR
        LRimage(i,j)=mean2(HRimage(ir:min([ir+bl-1+inc,Nhr]),jr:min([jr+bl-1+inc,Nhr])));
    end
end

%immagine LR
figure
axis equal
colormap gray
imagesc(LRimage)

% calcoliamo il contrasto per tutti gli sfasamenti
for inc=1:256
    bl=Nhr/Nlr;
    for i=1:Nlr
        for j=1:Nlr
            ir=(i-1)*bl+1;
            jr=(j-1)*bl+1;
            LRimage(i,j)=mean2(HRimage(ir:min([ir+bl-1+inc,Nhr]),jr:min([jr+bl-1+inc,Nhr])));
        end
    end
    M(inc)=max(LRimage(:))-100;
end

figure
plot(M)

