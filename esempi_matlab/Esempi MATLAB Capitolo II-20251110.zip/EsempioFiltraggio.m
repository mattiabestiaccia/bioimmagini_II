close all 
clear all

dicomlist = dir('Phantom_CT_PET/2-CT 2.5mm-5.464/*');   % load files
dicomlist=dicomlist(3:end); % exclude . and ..

for i=1:size(dicomlist)
    files(i)=string(strcat(dicomlist(i).folder,'/',dicomlist(i).name)); % file names
end

% get volume size and resolution from dicom 
info=dicominfo(files(1)); 
xSize=info.Rows;
ySize=info.Columns;
zSize=(size(dicomlist));
zSize=zSize(1);

dx=info.PixelSpacing(1);
dy=info.PixelSpacing(2);
loc1=info.ImagePositionPatient;
info1=dicominfo(files(2));
loc2=info1.ImagePositionPatient;
dz=pdist([loc1,loc2]'); 

volume=zeros(xSize,ySize,zSize);

FOV=[dx*xSize,dy*ySize,dz*zSize];

for i=1:size(dicomlist)
    volume(:,:,i)=dicomread(char(files(i)));
end


img=squeeze(volume(:,:,10));


k=15;
kernel = fspecial('average',k);
fimage= imfilter(img,kernel);
 
figure('NumberTitle', 'off', 'Name', 'Average filter');
axis('image') % preserve image proportions
subplot(1,3,1)
colormap gray
imagesc(img)
title('Original image');
set(gca,'xtick',[],'ytick',[])
subplot(1,3,2)
colormap gray
imagesc(fimage)
title('Filtered image');
set(gca,'xtick',[],'ytick',[])
%axis('image') % preserve image proportions
subplot(1,3,3)
imagesc(abs(img-fimage))
title('Difference Original/filtered');
set(gca,'xtick',[],'ytick',[])


k=15;
kernel = fspecial('disk',k);
fimage= imfilter(img,kernel);
 
figure('NumberTitle', 'off', 'Name', 'Disk filter');
axis('image') % preserve image proportions
subplot(1,3,1)
colormap gray
imagesc(img)
title('Original image');
set(gca,'xtick',[],'ytick',[])
subplot(1,3,2)
colormap gray
imagesc(fimage)
title('Filtered image');
set(gca,'xtick',[],'ytick',[])
%axis('image') % preserve image proportions
subplot(1,3,3)
imagesc(abs(img-fimage))
title('Difference Original/filtered');
set(gca,'xtick',[],'ytick',[])

figure
colormap gray
imagesc(kernel)
 
k=15;
kernel = fspecial('gaussian',k,2.5);
fimage= imfilter(img,kernel);
figure('NumberTitle', 'off', 'Name', 'Gaussian kernel');
axis('image')
surf(kernel)
 


figure('NumberTitle', 'off', 'Name', 'Gaussian filter');
axis('image') % preserve image proportions
subplot(1,3,1)
colormap gray
imagesc(img)
title('Original image');
set(gca,'xtick',[],'ytick',[])
subplot(1,3,2)
colormap gray
imagesc(fimage)
title('Filtered image');
set(gca,'xtick',[],'ytick',[])
%axis('image') % preserve image proportions
subplot(1,3,3)
imagesc(abs(img-fimage))
title('Difference Original/filtered');
set(gca,'xtick',[],'ytick',[])

k=15;
fimage= medfilt2(img,[k k]);
 
figure('NumberTitle', 'off', 'Name', 'Median filter');
axis('image') % preserve image proportions
subplot(1,3,1)
colormap gray
imagesc(img)
title('Original image');
set(gca,'xtick',[],'ytick',[])
subplot(1,3,2)
colormap gray
imagesc(fimage)
title('Filtered image');
set(gca,'xtick',[],'ytick',[])
%axis('image') % preserve image proportions
subplot(1,3,3)
imagesc(abs(img-fimage))
title('Difference Original/filtered');
set(gca,'xtick',[],'ytick',[])

imgTest=zeros(256);
imgTest(100:200,100:200)=100;
img1 = imnoise(imgTest,'salt & pepper');
fimage= medfilt2(img1,[5 5]);
figure('NumberTitle', 'off', 'Name', 'Median filter (s & p)');
axis('image') % preserve image proportions
subplot(1,3,1)
colormap gray
imagesc(img1)
title('Original image');
set(gca,'xtick',[],'ytick',[])
subplot(1,3,2)
colormap gray
imagesc(fimage)
title('Filtered image');
set(gca,'xtick',[],'ytick',[])
%axis('image') % preserve image proportions
subplot(1,3,3)
imagesc(abs(img1-fimage))
title('Difference Original/filtered');
set(gca,'xtick',[],'ytick',[])



k=5;
kernel = fspecial('sobel');
fimage= imfilter(img,kernel);
figure('NumberTitle', 'off', 'Name', 'Sobel filter');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(img)
title('Original image');
set(gca,'xtick',[],'ytick',[])
subplot(1,2,2)
colormap gray
imagesc(fimage)
title('Filtered image');
set(gca,'xtick',[],'ytick',[])




kernel = fspecial('laplacian',0.1);
fimage= imfilter(img,kernel);

figure('NumberTitle', 'off', 'Name', 'Gaussian kernel');
axis('image')
surf(kernel)


figure('NumberTitle', 'off', 'Name', 'Laplacian filter');
axis('image') % preserve image proportions
subplot(1,2,1)
imagesc(img)
colormap gray
title('Original image');
set(gca,'xtick',[],'ytick',[])
subplot(1,2,2)
imagesc(fimage)
colormap colorcube
title('Filtered image');
set(gca,'xtick',[],'ytick',[])
 


k=30;
fimage= medfilt2(img,[k k]);
 
figure('NumberTitle', 'off', 'Name', 'Median filter');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(fimage)
%axis('image') % preserve image proportions
subplot(1,2,2)
imagesc(img-fimage)


k=3;
%fimage= edge(img);
fimage= edge(img,'Canny');

figure('NumberTitle', 'off', 'Name', 'Edge map filter');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(fimage)
%axis('image') % preserve image proportions
subplot(1,2,2)
imagesc(img-fimage)



