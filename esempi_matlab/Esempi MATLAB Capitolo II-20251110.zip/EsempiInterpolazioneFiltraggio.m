close all 
clear all

dicomlist = dir('Phantom_CT_PET/2-CT 2.5mm-5.464/*');   % filel
dicomlist=dicomlist(3:end); % exclude . and ..

for i=1:size(dicomlist)
    files(i)=string(strcat(dicomlist(i).folder,'/',dicomlist(i).name)); % file names
end

% get volume size and resolution from dicom 
info=dicominfo(files(1)); 
xSize=info.Rows;
ySize=info.Columns;
zSize=(size(dicomlist));
zSize=zSize(1);

dx=info.PixelSpacing(1);
dy=info.PixelSpacing(2);
loc1=info.ImagePositionPatient;
info1=dicominfo(files(2));
loc2=info1.ImagePositionPatient;
dz=pdist([loc1,loc2]'); 

volume=zeros(xSize,ySize,zSize);

FOV=[dx*xSize,dy*ySize,dz*zSize];

for i=1:size(dicomlist)
    volume(:,:,i)=dicomread(char(files(i)));
end


% raw volume 
volumeViewer(volume);

%plane interpolation

img=squeeze(volume(:,:,10));
figure('NumberTitle', 'off', 'Name', 'Original');
axis('image') % preserve image proportions
colormap gray
imagesc(img)

figure('NumberTitle', 'off', 'Name', 'NN');
axis('image') % preserve image proportions
colormap gray
imagesc(imresize(img,2,'Method','nearest'))

figure('NumberTitle', 'off', 'Name', 'bilinear');
axis('image') % preserve image proportions
colormap gray
imagesc(imresize(img,2,'Method','bilinear'))

figure('NumberTitle', 'off', 'Name', 'bicubic');
axis('image') % preserve image proportions
colormap gray
imagesc(imresize(img,2,'Method','bicubic'))


newPlanes=zSize*dz/dx;
volumeInt = imresize3(volume,[xSize ySize newPlanes]);

% interpolated volume 
volumeViewer(volumeInt);


k=15;
kernel = fspecial('average',k);
fimage= imfilter(img,kernel);
 
figure('NumberTitle', 'off', 'Name', 'Mean filter');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(fimage)
%axis('image') % preserve image proportions
subplot(1,2,2)
imagesc(img-fimage)

 
k=25;
kernel = fspecial('gaussian',k,8.5);
fimage= imfilter(img,kernel);
figure('NumberTitle', 'off', 'Name', 'Gaussian kernel');
axis('image')
surf(kernel)
 
figure('NumberTitle', 'off', 'Name', 'Gaussian filter');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(fimage)
%axis('image') % preserve image proportions
subplot(1,2,2)
imagesc(img-fimage)

k=5;
kernel = fspecial('sobel');
fimage= imfilter(img,kernel);
 
figure('NumberTitle', 'off', 'Name', 'Sobel filter');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(fimage)
%axis('image') % preserve image proportions
subplot(1,2,2)
imagesc(img-fimage)



kernel = fspecial('laplacian',0.4);
fimage= imfilter(img,kernel);
 
figure('NumberTitle', 'off', 'Name', 'Laplacian filter');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(fimage)
%axis('image') % preserve image proportions
subplot(1,2,2)
imagesc(img-fimage)

k=30;
fimage= medfilt2(img,[k k]);
 
figure('NumberTitle', 'off', 'Name', 'Median filter');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(fimage)
%axis('image') % preserve image proportions
subplot(1,2,2)
imagesc(img-fimage)


k=3;
%fimage= edge(img);
fimage= edge(img,'Canny');

figure('NumberTitle', 'off', 'Name', 'Edge map filter');
axis('image') % preserve image proportions
subplot(1,2,1)
colormap gray
imagesc(fimage)
%axis('image') % preserve image proportions
subplot(1,2,2)
imagesc(img-fimage)



